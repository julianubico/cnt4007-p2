# Running the program
1. `python server.py`
2. `python client.py 5106` (new terminal)
3. `python client.py 5106` (new terminal)